CREATE TABLE attachments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT,
    file_path VARCHAR(255),
    uploaded_at DATETIME,
    CONSTRAINT fk_attachment_ticket
        FOREIGN KEY (ticket_id) REFERENCES tickets(id)
);